define(['./_createPredicateIndexFinder'], function (_createPredicateIndexFinder) {

	// Returns the last index on an array-like that passes a truth test.
	var findLastIndex = _createPredicateIndexFinder(-1);

	return findLastIndex;

});
