define(['./_tagTester'], function (_tagTester) {

	var isRegExp = _tagTester('RegExp');

	return isRegExp;

});
