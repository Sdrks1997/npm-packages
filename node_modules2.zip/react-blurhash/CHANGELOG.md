# Changelog

## 0.1.1 (July 1, 2019)

- `Blurhash` component's `width` and `height` can now also be a string (CSS property)
